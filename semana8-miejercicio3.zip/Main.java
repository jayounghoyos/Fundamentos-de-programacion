import java.util.Scanner;

class Main {
  public static double francosApesosConComision(double francos){
    francos = francos * 5339.54;
    francos = francos - (francos * 0.05);
    return francos;
  }
  public static void main(String[] args) {
    Scanner kb = new Scanner(System.in);
    
    double francosSuizos, cuentaColombia;
    System.out.println("Ingresa los francosSuizos que te ganaste: ");
    francosSuizos = kb.nextDouble();

    cuentaColombia = francosApesosConComision(francosSuizos);
    System.out.println("Tienes " + cuentaColombia + " $COP");
    
  }
}