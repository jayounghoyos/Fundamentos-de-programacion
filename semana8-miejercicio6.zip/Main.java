class Main {
  public static void llenado(int[] array){
    for(int i=0; i<array.length; i++){
     array[i] = i; 
    }
  }
  
  public static void invertirArray(int[] array1, int[] array2){
    for(int i=0; i<array1.length; i++){
      array2[i] = array1[(array1.length-1)-i];
    }
  }
  
  public static void MostrarArreglo(int[] array){
    for(int i=0; i<array.length; i++){
      System.out.println("Valor en posición " + i + " es " + array[i]);
    }
  }
  
  public static void main(String[] args) {
    int n = 7;
    int[] array1 = new int[n];
    int[] array2 = new int[n];
    
    System.out.println("Tamaño del arreglo que se hará con una serie matemática");
    
    llenado(array1);
	
  	System.out.println("--------------------");
  	System.out.println("Arreglo 1");
  	MostrarArreglo(array1);
  	
  	System.out.println("--------------------");
  	System.out.println("Arreglo 2");
  	invertirArray(array1, array2);
  	MostrarArreglo(array2);
    
  }
}