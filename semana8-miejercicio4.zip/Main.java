import java.util.Scanner;

class Main {
  public static int menu(int opcionLlenado, int opcionProcesamiento, int[] myArray) {
    if (opcionLlenado == 1) {
      serieAritmetica(myArray);
    } else if (opcionLlenado == 2) {
      int primerTermino = 2;
      int razon = 3; 
      serieGeometrica(myArray, primerTermino, razon);
    } else if (opcionLlenado == 3) {
      serieFibonacci(myArray);
    } else {
      datosDelUsuario(myArray);
    }

    if (opcionProcesamiento == 1) {
      return promedioArreglo(myArray);
    } else {
      return sumarArreglo(myArray);
    }
  }

  //opcion 1
  public static void serieAritmetica(int[] array) {
    for (int i = 0; i < array.length; i++) {
      array[i] = i * 2;
    }
  }
  
  //opcion 2
  public static void serieGeometrica(int[] array, int primerTermino, int razon) {
    for (int i = 0; i < array.length; i++) {
        array[i] = primerTermino * (int) Math.pow(razon, i);
    }
  }

  //opcion 3
  public static void serieFibonacci(int[] array) {
      int n1 = 0;
      int n2 = 1;
      int aux = 0;
      for (int i = 0; i < array.length; i++) {
          array[i] = n1;
          aux = n1 + n2;
          n1 = n2;
          n2 = aux;
      }
  }

  //opcion 4
  public static void datosDelUsuario(int[] array) {
    Scanner kb = new Scanner(System.in);
    for (int i = 0; i < array.length; i++) {
      System.out.print("Ingresa un valor para la posición" + i + "-");
      array[i] = kb.nextInt();
    }
  }
  
  //opcion 1 procesamiento
  public static int promedioArreglo(int[] array) {
    int suma = 0;
    for (int i = 0; i < array.length; i++) {
      suma += array[i];
    }
    return suma / array.length;
  }
  
  //opcion 2 procesamiento
  public static int sumarArreglo(int[] array) {
    int suma = 0;
    for (int i = 0; i < array.length; i++) {
      suma += array[i];
    }
    return suma;
  }

  public static void main(String[] args) {
    Scanner kb = new Scanner(System.in);
    System.out.println("Digita el tamaño del arreglo");
    int n = kb.nextInt();
    
    int[] myArray = new int[n];
    System.out.println("Digita la opcion de llenado");
    int opcionLlenado = kb.nextInt();
    
    System.out.println("Digita la opcion de procesamiento");
    int opcionProcesamiento = kb.nextInt();
    
    System.out.println("------------------");
    int resultado = menu(opcionLlenado, opcionProcesamiento, myArray);
    System.out.println("Resultado: " + resultado);
  }
}