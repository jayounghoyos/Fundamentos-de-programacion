import java.util.Scanner;

class Main {
  public static double conversor(int op, double COP, double dol, double trm){
    if(op == 1){
      return COP / trm;
    }else{
      return dol * trm;
    } 
  }
  
  public static void main(String[] args) {
    int option;
    double pesos, dolar, tasa;
    Scanner kb = new Scanner(System.in);
    
    System.out.println("opcion 1 : dolares a pesos");
    System.out.println("opcion 2 : pesos a dolares");
    System.out.println("ingresa la opción que quieras del conversor");
    option = kb.nextInt();
    
    System.out.println("ingresa los dolares");
    dolar = kb.nextDouble();
    System.out.println("ingresa los pesos");
    pesos = kb.nextDouble();
    System.out.println("ingresa la tasa");
    tasa = kb.nextDouble();
    
    System.out.println(conversor(option, pesos, dolar, tasa));
  }
}