import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner kb = new Scanner(System.in);
    System.out.println("Ingresa el texto: ");
    String texto1 = kb.nextLine();
    String newText;
    
    if(texto1.length() % 2 == 0){
      newText = String.valueOf(texto1.charAt(0)) + String.valueOf(texto1.charAt(texto1.length() - 1));
      System.out.println("El nuevo string es: " + newText);
    }else{
      newText = String.valueOf(texto1.charAt(0)) + String.valueOf(texto1.charAt(texto1.length() / 2)) + String.valueOf(texto1.charAt(texto1.length() - 1));
      System.out.println("El nuevo string es: " + newText);
    }
  }
}