import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner kb = new Scanner(System.in);
    System.out.println("Digita el string que quieres invertir:");
    
    String hw = kb.nextLine();

    for(int i = hw.length()-1; i>=0; i-=1){
      System.out.print(hw.charAt(i));
    }
  }
}