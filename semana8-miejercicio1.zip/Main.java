import java.util.Scanner;

class Main {
  public static double dolarPesos(double dol, double cambio){
    return dol * cambio;
  }

  public static double pesosDolar(double pesos, double cambio){
    return pesos / cambio;
  }
  
  public static void main(String[] args) {
    
    Scanner kb = new Scanner(System.in);

    double tPesos, tdolares, dolares, pesos, tasa;
    System.out.println("Ingresa los dolares");
    dolares = kb.nextDouble();
    System.out.println("ingresa los pesos");
    pesos = kb.nextDouble();
    System.out.println("ingresa la tasa");
    tasa = kb.nextDouble();

    tPesos = dolarPesos(dolares, tasa);
    System.out.println(tPesos + " Pesos");
    
    tdolares = pesosDolar(pesos, tasa);
    System.out.println(tdolares + "tPesos ");
  }
}