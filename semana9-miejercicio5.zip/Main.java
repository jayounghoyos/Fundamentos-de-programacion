import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner kb = new Scanner(System.in);
    
    System.out.println("Ingresa el primer string");
    String texto1 = kb.nextLine().toLowerCase();
    
    System.out.println("Ingresa el segundo string");
    String texto2 = kb.nextLine().toLowerCase();

    if(texto1.indexOf(texto2)!=-1){
      System.out.println("Es un substring");      
    }else{
      System.out.println("No es un substring");
    }
  }
}