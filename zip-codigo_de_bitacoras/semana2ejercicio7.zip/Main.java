import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    double var1, var2, temporal_value;

    System.out.println("Digita el primer valor");
    Scanner kb = new Scanner(System.in);
    var1 = kb.nextDouble();

    System.out.println("Digita el segunto valor");
    var2 = kb.nextDouble();

    System.out.println("Primeros valores(sin todavía cambiarlos) valor1: " + var1 + " valor2: " + var2);

    temporal_value = var1;
    var1 = var2;
    var2 = temporal_value;

    System.out.println("Valores intercambiados");
    System.out.println("valo1: " + var1 + " valor 2: " + var2);

    kb.close();
  }
}