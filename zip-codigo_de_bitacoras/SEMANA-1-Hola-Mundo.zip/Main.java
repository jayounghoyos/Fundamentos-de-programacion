class Main {
  public static void main(String[] args) {
    System.out.println("¡Hola mundo!");
    System.out.println("¡Quiero ser el mejor programador del mundo!");
  }
}