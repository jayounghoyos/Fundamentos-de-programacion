import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    int num;
    double unidades, decenas;

    System.out.println("Digita el número que quieres invertir");
    Scanner kb = new Scanner(System.in);
    num = kb.nextInt();

    unidades = num % 10;
    decenas = Math.round(num / 10);

    System.out.println("El número invertido es " + (unidades * 10 + decenas));

    kb.close();
  }
}