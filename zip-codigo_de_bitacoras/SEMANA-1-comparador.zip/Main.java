import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        System.out.println("Hola");
        System.out.println("Bienvenido al comparador de variables!");

        int a;
        int b;

        Scanner var_a = new Scanner(System.in);
        System.out.println("Digita el número de la primera variable: ");
        a = var_a.nextInt();

        Scanner var_b = new Scanner(System.in);
        System.out.println("Digita el número de la segunda variable: ");
        b = var_b.nextInt();

        System.out.println("La variable a: " + a + " y la variable b: " + b);
  
        if (a > b) {
            System.out.println("a es mayor que b.");
        } else if (a < b) {
            System.out.println("a es menor que b.");
        } else {
            System.out.println("a es igual a b.");
        }
    }
}
