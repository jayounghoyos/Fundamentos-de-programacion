import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    int a,b,c;

    Scanner kb = new Scanner(System.in);
      
    System.out.println("Digita el valor de a");
    a = kb.nextInt();

    System.out.println("Digita el valor de b");
    b = kb.nextInt();

    System.out.println("Digita el valor de c");
    c = kb.nextInt();

    if (a = b + c){
      System.out.println("a es igual a, b + c");
    }else{
      if(b = c + a){
        System.out.println("b es igual a, c + a");
      }else{
        if(c = a + b){
          System.out.println("c es igual a, a + b");
        }else{
         System.out.println("Diferentes"); 
        }
      }
    }
    kb.close();
  }
}