import java.util.Scanner;
  
class Main {
  public static void main(String[] args) {

    int num; 

    System.out.println("Digita el valor del numero para saber si es par o impar");
    
    Scanner kb = new Scanner(System.in);
    num = kb.nextInt();

    if (num%2 == 0){
      System.out.println("Es par");
    }else{
      System.out.println("Es impar");
    }
    
    kb.close();
  }
}