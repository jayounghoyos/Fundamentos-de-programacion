import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    int i, j, num;
    boolean es_primo;

    System.out.println("Digita un número y que sea mayor a 1: ");
    Scanner kb = new Scanner(System.in);
    num = kb.nextInt();
    
    j = 0;

    while (num != 0){
      if (num <= 1){
        System.out.println("Número invalido");
      }else{
        i = 2;
        es_primo = true;
        while (i < num) {
          if (num % i == 0) {
            es_primo = false;
          }
          i +=1;
        }
        if (es_primo){
          j += 1;
        }
        System.out.println("Digita otro número");
        num = kb.nextInt();
      }
    }
    System.out.println("Hay " + j + " números primos");
    kb.close();
  }
}