import java.util.Random;
import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    int user, bot, intentos;

    Random myrandom = new Random();
    bot = myrandom.nextInt(2);
    intentos = 1;

    System.out.println("Digita el numero que creas igual al de la maquina (entre 0 y 100)");  
    Scanner kb = new Scanner(System.in);
    user = kb.nextInt();
    
    while (user != bot){
      System.out.println("Digita un numero");  
      user = kb.nextInt();
      if (user<0 || user >100){
        System.out.println("Debes ingresar un número entre 0 y 100.");
      }else{
        if(user == bot){
          System.out.println("¡Acertaste!");
        }else{
          if (user >bot){
            System.out.println("El número que ingresaste es mayor que el número aleatorio.");
          }else{
            System.out.println("El número que ingresaste es menor que el número aleatorio.");
          }
        }
        intentos = intentos + 1;
      }
    }    
    System.out.println("Número de intentos: " + intentos);

    kb.close();
  }
}