class Main {
  public static void main(String[] args) {
    int n, i;
    n = 7;

    System.out.println("Tamaño del arreglo que se hará con una serie matemática: ");
    int array1[] = new int[n];
    int array2[] = new int[n];

    for(i=0; i<n; i+=1){
      array1[i] = i;
      System.out.println(array1[i]);
    }
    System.out.println("-----");
    for(i=0; i<n; i+=1){
      System.out.println("valor en la posición " + i + " es " + array1[i]);
    }
    System.out.println("-----");
    for(i=0; i<n; i+=1){
      array2[i] = array1[(n-1)-i];
		  System.out.println(array2[i]);
    }
  }
}