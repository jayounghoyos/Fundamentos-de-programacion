import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    int a,b,c;

    Scanner kb = new Scanner(System.in);

    System.out.println("Digita el valor de a");
    a = nextInt();

    System.out.println("Digita el valor de b");
    b = nextInt();

    System.out.println("Digita el valor de c");
    c = nextInt();
    
    if(a < b && b < c){
      System.out.println("Ordenados");
    }else{
      System.out.println("No ordenados");  
    }
  }
}