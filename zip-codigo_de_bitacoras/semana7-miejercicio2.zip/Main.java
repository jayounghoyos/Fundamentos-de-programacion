class Main {
  public static void main(String[] args) {
    int n, i, j;

    n = 10;

    int datos1[] = new int[n];
    int datos2[] = new int[n];

    for(i = 0; i<n; i+=1){
      datos1[i] = i*2;      
    }
    System.out.println("-----");
    
    for(i=0; i<n; i+=1){
      System.out.println("Datos valor en la posición " + i + " es " + datos1[i]);
    }
    

    i = n-1;
    j = 0;

    while (j<n){
      datos2[j] = datos1[i];
      j = j + 1;
      i = i - 1;
    }
    System.out.println("-----");

    for(j=0; j<n; j+=1){
      System.out.println("datos2 valor en la posición " + j + " es " + datos2[j]);
    }
  }
}