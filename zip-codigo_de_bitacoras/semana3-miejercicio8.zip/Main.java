import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    int mes;
    double dolar_inicial, inversion, dolares, dolar_baja, dolar_aumenta;

    Scanner kb = new Scanner(System.in);

    System.out.println("Digita el valor del dolar al principio del año");
    dolar_inicial = kb.nextDouble();

    System.out.println("Digita el valor del dolar al principio del año");
    mes = kb.nextInt();
    
    if(mes < 1 || mes>12){
      System.out.println("Error del mes");
    }else{
      System.out.println("Ingrese la cantidad del dinero en pesos a invertir: "); 
      inversion = kb.nextInt();
      if(inversion < 100000 || inversion > 20000000 || inversion%100000 != 0){
        System.out.println("Error en la cantidad a invertir");
      }else{
        if(mes >=1 && mes <=3){
          dolares = inversion/ dolar_inicial;
        }
        if(mes >= 4 && mes<= 6){
          dolar_baja = dolar_inicial - (dolar_inicial * 0.5);
          dolares = inversion / dolar_baja;
        }
        if(mes >= 7 && mes <= 9){
          dolar_baja = dolar_inicial - (dolar_inicial * 0.5);
          dolares = inversion / dolar_baja;
        }
        if(mes >=10 && mes<=12){
          dolar_baja = dolar_inicial - (dolar_inicial * 0.05);
          dolar_aumenta = dolar_baja + (dolar_baja * 0.10);
          dolares = inversion / dolar_aumenta;
        }
      }
    }
    kb.close();
  }
}