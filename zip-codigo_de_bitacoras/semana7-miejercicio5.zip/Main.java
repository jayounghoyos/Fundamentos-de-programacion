class Main {
  public static void main(String[] args) {
    int n, aux, i;

    n = 8;

    int array1[] = new int[n]; 

    for(i=0; i<n; i+=1){
      array1[i] = i;
    }

    System.out.println("Arreglo 1");
    for(i=0; i<n; i+=1){
       System.out.println(array1[i]); 
    }
    System.out.println("Arreglo invertido");
    for(i=0; i<(n/2); i+=1){
      aux = array1[i];
		  array1[i] = array1[n-1-i];
		  array1[n-1-i] = aux;
    }
    for(i=0; i<n; i+=1){
      System.out.println(array1[i]);
    }
  }
}