import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    Double nota;
    
    System.out.println("Digita la nota que obtuviste");
    Scanner kb = new Scanner(System.in);

    nota = kb.nextDouble();

    if (nota == 5){
      System.out.println("Excelente");
    }else{
      if(4.5 <= nota && nota<= 4.9){
        System.out.println("Muy bien");
      }else{
        if(4 <= nota && nota<= 4.4){
          System.out.println("Bien");
        }else{
          if(3<= nota && nota<= 3.9){
            System.out.println("Regular");
          }else{
            if(1.5 <= nota && nota<= 2.9){
              System.out.println("Mal");
            }else{
              if(0 <= nota && nota<= 1.4){
                System.out.println("Muy mal");
              }else{
                System.out.println("la nota debe estar entre 0 y 5");  
              }
            }
          }
        }
      }
    }
    kb.close();
  }
}