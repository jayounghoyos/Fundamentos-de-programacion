import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    int num, n, resultado;

    Scanner kb = new Scanner(System.in);
    System.out.println("Digita el número al que le quieras sacar factorial");
    num = kb.nextInt();

    n = num;
    resultado = 1;
    while (n>0){
     resultado = resultado*n;
     n = n-1;
    }
    System.out.println("El factorial es: " + resultado);
    kb.close();
  }
}