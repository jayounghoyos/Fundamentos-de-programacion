import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    
    int i, n, val, total, m;
    double prom;
    
    System.out.println("Digita el número n de veces");
    Scanner kb = new Scanner(System.in);
    n = kb.nextInt();
    System.out.println("----");
    
    prom = 0;
    i = 1;

    while (i <= n){
      val = kb.nextInt();
      m = 0;
      total = 0;
      
      while (val != 0){
        if (val == -1){
          prom = total/m;
          System.out.println(prom);
        }else if (val>0){
          m = m +1;
          total = total + val;
        }
      
        val = kb.nextInt();
      }
      if(m > 0){
        prom = total/m;
        System.out.println(prom);
      }
      i += 1;
    }
    System.out.println("finish");
  }
}