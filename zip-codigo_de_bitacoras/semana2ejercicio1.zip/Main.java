import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    //definir variables
    double a,b,c;
    
    //Recibir datos
    Scanner kb = new Scanner(System.in);
    System.out.println("Ingrese el valor de a");
    a = kb.nextDouble();
      
    System.out.println("Ingrese el valor de a");
    b = kb.nextDouble();

    //Operaciones con los datos
    c = a + b;
    System.out.println("El resultado de la suma a + b es: " + c);

    c = a - b;
    System.out.println("El resultado de la resta a - b es: " + c);

    c = a * b;
    System.out.println("El resultado de la multiplicación a * b es: " + c);

    c = a / b;
    System.out.println("El resultado de la division de a / b es: " + c);
  }
}