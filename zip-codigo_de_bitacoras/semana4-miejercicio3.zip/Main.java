import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    int a, b, i;
    Scanner kb = new Scanner(System.in);
    
    System.out.println("Digita el valor de a: ");
    a = kb.nextInt();
    System.out.println("Digita el valor de b: ");
    b = kb.nextInt();

    i=1;
    
    while (i<b){
      if (a>=0){
        System.out.println("+" + a);
        i += 1;
      }else{
        System.out.println(a);
        i += 1;
      }
    }
    System.out.println("El resultado es:" + a*b);

    kb.close();
  }
}