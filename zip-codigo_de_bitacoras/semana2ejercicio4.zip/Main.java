import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    
    int num1, num2;
    double num3;
    
    System.out.println("Digita el primer dato para empezar con el promedio");
    Scanner kb = new Scanner(System.in);
    num1 = kb.nextInt();

    System.out.println("Digita el segundo dato");
    num2 = kb.nextInt();

    System.out.println("Digita el tercer dato");
    num3 = kb.nextDouble();

    System.out.println("El promedio de los tres números es: " + (num1 + num2 + num3)/3);
    kb.close();
  }
}