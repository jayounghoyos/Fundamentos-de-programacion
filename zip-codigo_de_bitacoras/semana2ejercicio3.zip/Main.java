import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    double fahrenheit, celcius;
    
    System.out.println("****Bienvenido al conversor de Fahrenheit a celcius****");
    System.out.println("Digita los grados Fahrenheit que quieras convertir a celcius");

    Scanner F = new Scanner(System.in);

    fahrenheit = F.nextDouble();
    
    celcius = (fahrenheit-32)*5/9;

    System.out.println("convertidos a grados celcius serían: " + celcius + "°c");
  }
}