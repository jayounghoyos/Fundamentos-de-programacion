import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    
    double x1, y1, x2, y2;
    
    System.out.println("Digita la primera abscisa, x1");
    Scanner kb = new Scanner(System.in);
    x1 = kb.nextDouble();

    System.out.println("Digita la primera ordenada, y1");
    y1 = kb.nextDouble();

    System.out.println("Digita la segunda abscisa, x2");
    x2 = kb.nextDouble();
    
    System.out.println("Digita la segunda ordenada, y2");
    y2 = kb.nextDouble();

    System.out.println("La distancia entre los dos puntos es de: " + Math.sqrt(Math.pow((x2-x1),2) + Math.pow((y2-y1),2)));
    kb.close();
  }
}