import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    int inicialYear, finalYear, i, auxi, auxf;

    Scanner kb = new Scanner(System.in);
    
    System.out.println("Los números negativos son a.c y los positivos D.C");
    System.out.println("Digita el año de inicio");
    inicialYear = kb.nextInt();
    auxi = inicialYear;
    
    System.out.println("Digita el año de terminación");
    finalYear = kb.nextInt();
    auxf = finalYear;

    i = 0;

    while (inicialYear <= finalYear){
      if ((inicialYear % 4 == 0 && inicialYear % 100 != 0) || (inicialYear % 10 == 0) || inicialYear % 400 == 0){
         System.out.println(inicialYear);
        i += 1;
      }
      inicialYear += 1;
    }
    System.out.println("Hay " + i + " años bisiestos y años divisibles entre 10 en el año " + auxi + " al " + auxf);
  }
}