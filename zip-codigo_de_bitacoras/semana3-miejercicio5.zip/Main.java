import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    int a, b;

    Scanner kb = new Scanner(System.in);
    
    System.out.println("Digita el valor de la variable a");
    a = nextInt();

    System.out.println("Digita el valor de la variable b");
    b = nextInt();
    
    
    if(a == 0){
      System.out.println("a no puede ser cero, no es valido como divisor");
    }else{
      if(b%a == 0){
        System.out.println("a es divisor entero de b");
      }else{
        System.out.println("a no es divisor entero de b");
      }
    }
    kb.close();
  }
}