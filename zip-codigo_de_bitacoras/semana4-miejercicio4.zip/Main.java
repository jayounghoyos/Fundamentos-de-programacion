import java.util.Scanner;
class Main {
  public static void main(String[] args) {
  
  int i, n;
  String aster;

  aster = "*";
  i=1;
    
  Scanner kb = new Scanner(System.in);
  
  System.out.println("Ditiga la longitud que tendrá la altura y la base del triangulo:");
 n = kb.nextInt();

  if(n>20 && n<1){
    System.out.println("Digita un número que no este entre 1 y 20");
  }else{
    while (i<=n){
      System.out.println(aster);

      aster = aster + "*";
      i += 1;
    }
  }
  kb.close();
  }
}