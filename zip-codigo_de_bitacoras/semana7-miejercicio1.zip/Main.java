import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    int i = 0;
    
    Scanner kb = new Scanner(System.in);
    
    System.out.println("Digita el tamaño que tendrá el arreglo: "); 
    int n = kb.nextInt();

    int[] arr_int = new int[n];
    
    for(i = 0; i<n; i+=1){
      System.out.println("Digita el dato en la posición " + i);
      int dato = kb.nextInt();
      arr_int[i] = dato * 2;
      System.out.println("El valor es: " + arr_int[i]);   
    }
    System.out.println("---------------------");
    
    for(i=0; i < n; i+=1){
     System.out.println("El valor en la posición " + i + " es " + arr_int[i]*3);
    }
    kb.close();
  }
}