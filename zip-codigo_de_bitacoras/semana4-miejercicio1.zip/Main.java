import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    int n1, n2, n, i, aux;
    i=1;
    n1=1;
    n2=1;
    
    System.out.println("Ingresa los n números que quieres que aparezcan");
    Scanner kb = new Scanner(System.in);
    n= kb.nextInt();

    System.out.println("---");
    System.out.println(n1);
    System.out.println(n2);
    
    while (i <= n-2){
      aux = n1 + n2;
      n1 = n2;
      n2 = aux;
      System.out.println(n2);
      i = i+1;
    }
    kb.close();
  }
}