import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    int a,b,c;
    
    Scanner kb = new Scanner(System.in);
      
    System.out.println("Digita el valor de a");
    a = kb.nextInt();

    System.out.println("Digita el valor de b");
    b = kb.nextInt();

    System.out.println("Digita el valor de c");
    c = kb.nextInt();

    if(a <= b && a <= c){
      if(b <= c){
          System.out.println("El orden es:" + " a: " + a + " b: " + b + " c: " + c);
      }else{
        System.out.println("El orden es:" + " a: " + a + " c: " + c + " b: " + b);
      }
    }else{
      if(b<= a && b<= c){
        if(a <= c){
          System.out.println("El orden es:" + " b: " + b + " a: " + a + " c: " + c);
        }else{
        System.out.println("El orden es:" + " b: " + b + " c: " + c + " a: " + a);
        }
      }else{
        if(a <= b){
          System.out.println("El orden es:" + " c: " + c + " a: " + a + " b: " + b);
        }else{
          System.out.println("El orden es:" + " c: " + c + " b: " + b + " a: " + a);
        }
      }
    }
    kb.close();
  }
}