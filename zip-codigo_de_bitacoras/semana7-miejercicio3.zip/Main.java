import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    int n, i, val;

    Scanner kb = new Scanner(System.in);
    System.out.println("Digita el número de datos que quieras ingresar al arreglo");
    n = kb.nextInt();

    int arr_int[] = new int [n];
    int arr_int2[] = new int [n];

    for(i=0; i<n; i+=1){
      System.out.println("Digita el valor en la posición: " + i);
      val = kb.nextInt();

      arr_int[i] = val;
    }
    
    //Arreglo 1
    System.out.println("Arreglo1");
    for(i=0; i<n; i+=1){
      System.out.println(arr_int[i]);
    }

    //Arreglo 2
    System.out.println("Arreglo2");
    for(i=0; i<n; i+=1){
      arr_int2[i] = arr_int[(n-1)-i];
    }
    for(i=0; i<n; i+=1){
      System.out.println(arr_int2[i]);
    }
    
    kb.close();
  }
}