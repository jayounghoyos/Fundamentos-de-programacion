import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    
    double valor_pesos, valor_dolares;
    int op;
    double tasa_de_cambio = 3930.86;
    
    System.out.println("**********Bienvenido al conversor de moneda*********");
    System.out.println("Elige la opción que quieras (número de la opción)");
    System.out.println("1) pesos a dólares");
    System.out.println("2) dólares a pesos");
    
    Scanner kb_op = new Scanner(System.in);
    op = kb_op.nextInt();
    
    switch (op) { 
      case 1:
        System.out.println("Digita el dinero en pesos que quieres cambiar");
        Scanner kb = new Scanner(System.in);
        valor_pesos = kb.nextDouble();
        System.out.println("La conversión de tus pesos a dólares es de: " + valor_pesos / tasa_de_cambio + "dolares");
        break;
      case 2:
        System.out.println("Digita el dinero en dolares que quieres cambiar");
        Scanner dol_value = new Scanner(System.in);
        valor_dolares = dol_value.nextDouble(); 
        System.out.println("La conversión de tus dolares a pesos es de: " + valor_dolares * tasa_de_cambio + "pesos");
        break;
  }
  }
}