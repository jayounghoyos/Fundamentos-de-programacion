import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    int num, i;
    boolean es_primo;

    System.out.println("Digita el número: ");
    Scanner kb = new Scanner(System.in);
    num = kb.nextInt();

    i = 2;

    if (num <= 1){
      System.out.println("Digita un número mayor a 1");
    }else{
      while (i < num){
       if (num % i == 0){
         i+= 1;
         System.out.println("No es primo");
         break;
      }else{
         System.out.println("Es primo");
         break;
      }
     } 
    i += 1;
    }
    kb.close();
  }
}