import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    int n, i;

    Scanner kb = new Scanner(System.in);
    System.out.println("Digita el tamaño que tendrá el arreglo 1");
    n = kb.nextInt();

    int array1[] = new int[n];
    float array2[] = new float[n/2];

    if(n%2 == 0){
      for(i=0; i<n; i+=1){
        array1[i] = i;
      }
      //Este es para Mostrar los valores de array1
      System.out.println("array1:");
      for(i=0; i<n ; i+=1){
        System.out.println(array1[i]);
      }

      for(i=0; i<(n/2); i+=1){
        array2[i] = (array1[i*2] + array1[i*2 + 1])/2.0f;
      }
      System.out.println("array2:");
      for(i=0; i<(n/2); i+=1){
        System.out.println(array2[i]);
      }
    }else{
      System.out.println("n debe ser par");  
    }
    kb.close();
  }
}