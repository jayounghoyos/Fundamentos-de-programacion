import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    int n, i, num, esPrimo, divisor;
    
    System.out.println("Ingrese la cantidad n de primos a generar: ");
    Scanner kb = new Scanner(System.in);
    n = kb.nextInt();

    i=0;
    num=2;
    
    System.out.println("...");
    if(n<0){
      System.out.println("Ingrese un valor mayor a 0");
    }else{
      while (i< n) {
        esPrimo = 1;
        divisor = 2;
        while (divisor < num) {
          if(num% divisor == 0){
            esPrimo=0;
          }
          divisor = divisor + 1;
        }
        if(esPrimo ==1){
          System.out.println(num);
          i+=1;
        }
        num +=1;
      }
    }
    kb.close();
  }
}