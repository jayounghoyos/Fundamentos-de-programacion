import java.util.Scanner;
class Main {
   public static void encontrarTodas(String texto, String buscarTexto) {
    int pos = 0;
    while ((pos = texto.toLowerCase().indexOf(buscarTexto.toLowerCase(), pos)) != -1) {
      System.out.println("Encontrado en la posición: " + pos);
      pos++;
    }
  }
  
  public static void main(String[] args) {
    String textoKb, caracter;
    
    Scanner kb = new Scanner(System.in);
    System.out.println("Ingresa el string: ");
    textoKb = kb.nextLine();

    System.out.println("Ingresa el caracter a buscar: ");
    caracter = kb.nextLine();

    encontrarTodas(textoKb, caracter);
    
    
  }
}