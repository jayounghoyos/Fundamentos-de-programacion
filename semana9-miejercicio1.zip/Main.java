class Main {
  public static void encontrarTodas(String texto, String buscarTexto) {
    int pos = 0;
    while ((pos = texto.toLowerCase().indexOf(buscarTexto.toLowerCase(), pos)) != -1) {
      System.out.println("Encontrado en la posición: " + pos);
      pos++;
    }
  }

  public static void main(String[] args) {
    String str1 = "Esta es una prueba de string, que verifica donde esta un string";
    String str2 = "esta";
    String str3 = "string";

    System.out.println("(esta) encotrado en str1:");
    encontrarTodas(str1, str2);

    System.out.println("");

    System.out.println("(string) encontrado en str1:");
    encontrarTodas(str1, str3);
  }
}
                                     
/*Clase*/
//String str1_mayusculas = str1.toUpperCase();
//String str2 = "esta";
//int pos = 0;
/*while(str1.indexOf(str2,pos)!=-1){
  pos = str1.indexOf(str2,pos);
  System.out.println("Encontrado en: " + pos);
  pos = pos + 1;
} */   
//String str2_mayusculas = str2.toUpperCase();
//String str = "string";
//System.out.println("En str el str2 esta en: " + str1_mayusculas.indexOf(str2_mayusculas,10));