import java.util.Scanner;
class Main {
  public static void main(String[] args) {
        
    Scanner kb = new Scanner(System.in);
    System.out.println("Ingresa el texto que quieres invertir");
    String texto1 = kb.nextLine();

    String textoAlreves = "";
    for(int i = texto1.length()-1; i>=0; i--){
      textoAlreves += texto1.charAt(i);
    }

    System.out.println("El texto al reves es: " + textoAlreves);
      
    
  }
}