import java.util.Scanner;

class Main {
  public static double menu(int opc, Scanner kb) {
    if (opc == 1) {
      double base, altura;
      System.out.println("Digita la base");
      base = kb.nextDouble();
      System.out.println("Digita la altura");
      altura = kb.nextDouble();
      return triangulo(base, altura);
    } else if (opc == 2) {
      double radio;
      System.out.println("Digita el radio");
      radio = kb.nextDouble();
      return circunferencia(radio);
    } else {
      double altura, baseMayor, baseMenor;
      System.out.println("Digita la altura");
      altura = kb.nextDouble();
      System.out.println("Digita la baseMayor");
      baseMayor = kb.nextDouble();
      System.out.println("Digita la baseMenor");
      baseMenor = kb.nextDouble();
      return cuadrilatero(baseMayor, baseMenor, altura);
    }
  }

  public static double triangulo(double base, double altura) {
    return (base * altura) / 2;
  }

  public static double circunferencia(double radio) {
    return 3.14159265359 * Math.pow(radio, 2); 
  }

  public static double cuadrilatero(double baseMayor, double baseMenor, double altura) {
    return ((baseMayor + baseMenor) * altura) / 2;
  }

  public static void main(String[] args) {
    int option;
    double area;

    Scanner kb = new Scanner(System.in);

    System.out.println("----Bienvenido al saca áreas-----");
    System.out.println("Digita la opción de la figura a la que le quieras sacar el área");
    System.out.println("1) triángulo");
    System.out.println("2) circunferencia");
    System.out.println("3) cuadrilátero");
    System.out.println("---------------------------------");
    option = kb.nextInt();

    area = menu(option, kb); 
    System.out.println("El área de la figura elegida es: " + area);
  }
}
